package com.strabag.fileParsingApp.addJob;

public class register_Job {

	// API for adding a job for file parsing
	// it should return the id of the job

	private long jobId;

	private String Class;

}
