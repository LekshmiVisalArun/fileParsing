package com.strabag.fileParsingApp;

public class GeoClass {

}
