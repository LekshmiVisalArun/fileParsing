package com.strabag.fileParsingApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileParsingApplicationTests {

	@Test
	void contextLoads() {
	}

}
